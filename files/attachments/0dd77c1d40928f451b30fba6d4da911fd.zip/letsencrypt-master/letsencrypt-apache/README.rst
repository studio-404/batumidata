Apache plugin for Let's Encrypt client
