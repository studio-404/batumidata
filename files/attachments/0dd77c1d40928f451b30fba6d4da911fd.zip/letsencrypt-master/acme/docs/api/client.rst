Client
------

.. automodule:: acme.client
   :members:
