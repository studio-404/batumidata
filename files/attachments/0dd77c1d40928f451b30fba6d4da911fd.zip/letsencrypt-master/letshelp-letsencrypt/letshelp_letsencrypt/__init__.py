"""Tools for submitting server configurations"""
